'use client';

import { useEffect, useRef, useState, useLayoutEffect } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Song } from '@/types/music';
import { Play, PlaySquare, Heart, ListPlus, Disc3, Mic2, Share, X, Radio } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { usePlayer } from '@/context/PlayerContext';
import { useIsMobile } from '@/hooks/useIsMobile';
import Image from 'next/image';
import { getBestImageUrl } from '@/lib/api/musicApi';
import { useAuth } from '@/context/AuthContext';
import { useLikedSongsIndex, useToggleLikedSong } from '@/hooks/useMusicLibrary';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';
import { resolveToYoutubeId } from '@/lib/youtube';
import { PlaylistSubMenu } from './context-menu/PlaylistSubMenu';

interface TrackContextMenuProps {
  track: Song | null;
  isOpen: boolean;
  position: { x: number; y: number } | null;
  onClose: () => void;
}

export function TrackContextMenu({ track, isOpen, position, onClose }: TrackContextMenuProps) {
  const router = useRouter();
  const isMobile = useIsMobile();
  const { playNext, addToQueue, playTrack, isAutoplayEnabled, toggleAutoplay } = usePlayer();
  const { user, signInWithGoogle } = useAuth();

  // Likes
  const { likedSet } = useLikedSongsIndex();
  const toggleLikeMutation = useToggleLikedSong();
  const isLiked = track ? likedSet.has(track.id) : false;
  const [showPlaylists, setShowPlaylists] = useState(false);

  const menuRef = useRef<HTMLDivElement>(null);

  // Close on outside click, scroll, resize, escape
  useEffect(() => {
    if (!isOpen) return;

    const handleOutsideClick = (e: MouseEvent | TouchEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        onClose();
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };

    const handleScroll = () => {
      if (!isMobile) onClose();
    };

    document.addEventListener('mousedown', handleOutsideClick);
    document.addEventListener('touchstart', handleOutsideClick);
    document.addEventListener('keydown', handleKeyDown);
    window.addEventListener('scroll', handleScroll, true);
    window.addEventListener('resize', onClose);

    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('touchstart', handleOutsideClick);
      document.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('scroll', handleScroll, true);
      window.removeEventListener('resize', onClose);
    };
  }, [isOpen, onClose, isMobile]);

  // Reset sub-menus when closed
  useEffect(() => {
    if (!isOpen) setShowPlaylists(false);
  }, [isOpen]);

  // Clamp position to viewport
  useLayoutEffect(() => {
    if (isOpen && position && menuRef.current && !isMobile) {
      const el = menuRef.current;
      // Temporarily reset to requested position to get natural bounds if it was clamped before
      el.style.left = `${position.x}px`;
      el.style.top = `${position.y}px`;

      const rect = el.getBoundingClientRect();
      let x = position.x;
      let y = position.y;

      if (x + rect.width > window.innerWidth) {
        x = window.innerWidth - rect.width - 10;
      }
      if (y + rect.height > window.innerHeight) {
        y = window.innerHeight - rect.height - 10;
      }

      el.style.left = `${Math.max(10, x)}px`;
      el.style.top = `${Math.max(10, y)}px`;
    }
  }, [isOpen, position, isMobile, showPlaylists]);

  if (!track) return null;

  const handleAction = async (action: () => void | Promise<void>) => {
    await action();
    if (!showPlaylists) { // don't close if we just toggled playlist view
      onClose();
    }
  };

  const handleLike = async () => {
    if (!user) {
      await signInWithGoogle();
      return;
    }
    toggleLikeMutation.mutate(track.id);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: track.name,
          text: `Check out ${track.name} by ${track.artists.primary[0]?.name}`,
          url: window.location.href, // or track.url
        });
      } catch (err) {
        // user cancelled or error
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast.success('Link copied to clipboard');
    }
  };

  const handleCreateStation = async () => {
    toast.promise(
      (async () => {
        let videoId = track.id;
        // If it's a generic itunes or backend id without 'yt-', resolve it
        if (!videoId.startsWith('yt-')) {
          const resolved = await resolveToYoutubeId(track.name, track.artists.primary[0]?.name || '', track.id);
          if (resolved) videoId = resolved;
        } else {
          videoId = videoId.replace('yt-', '');
        }

        const titleParams = new URLSearchParams({
          title: track.name,
          artist: track.artists.primary[0]?.name || '',
          userId: user?.id || 'anonymous'
        });

        const res = await fetch(`/api/audio/related/${videoId}?${titleParams.toString()}`);
        if (!res.ok) throw new Error('Failed to fetch station tracks');

        const data = await res.json();
        const suggestions: Song[] = data.songs || [];

        if (!suggestions || suggestions.length === 0) {
          throw new Error('No similar tracks found');
        }

        // Tag as autoplay so QueueManager handles them nicely
        const taggedSuggestions = suggestions.map(s => ({ ...s, isAutoplay: true }));

        playTrack(track, [track, ...taggedSuggestions]);

        if (!isAutoplayEnabled) {
          toggleAutoplay();
        }

        return 'Station created';
      })(),
      {
        loading: 'Creating station...',
        success: (msg) => msg,
        error: 'Failed to create station',
      }
    );
  };

  const hasAlbum = !!track.album.id;
  const hasArtist = track.artists.primary.length > 0 && !!track.artists.primary[0].id;

  const renderMenuItems = () => {
    if (showPlaylists) {
      return (
        <PlaylistSubMenu 
          track={track} 
          onClose={onClose} 
          onBack={() => setShowPlaylists(false)} 
        />
      );
    }

    return (
      <div className="py-1">
        <button
          onClick={() => handleAction(() => playNext(track))}
          className="w-full text-left px-4 py-3 text-[14px] font-medium text-white transition-colors hover:bg-white/10 flex items-center gap-3"
        >
          <PlaySquare size={16} className="text-white/60" />
          Play Next
        </button>
        <button
          onClick={() => handleAction(() => addToQueue(track))}
          className="w-full text-left px-4 py-3 text-[14px] font-medium text-white transition-colors hover:bg-white/10 flex items-center gap-3"
        >
          <ListPlus size={16} className="text-white/60" />
          Play Last
        </button>

        <div className="my-1 border-t border-white/10" />

        <button
          onClick={(e) => { e.stopPropagation(); handleLike(); onClose(); }}
          className={cn(
            "w-full text-left px-4 py-3 text-[14px] font-medium transition-colors hover:bg-white/10 flex items-center gap-3",
            isLiked ? "text-primary" : "text-white"
          )}
        >
          <Heart size={16} fill={isLiked ? "currentColor" : "none"} className={isLiked ? "" : "text-white/60"} />
          {isLiked ? 'Remove from Library' : 'Add to Library'}
        </button>
        <button
          onClick={(e) => { e.stopPropagation(); setShowPlaylists(true); }}
          className="w-full text-left px-4 py-3 text-[14px] font-medium text-white transition-colors hover:bg-white/10 flex items-center gap-3"
        >
          <ListPlus size={16} className="text-white/60" />
          Add to a Playlist
        </button>
        <button
          onClick={() => handleAction(handleCreateStation)}
          className="w-full text-left px-4 py-3 text-[14px] font-medium text-white transition-colors hover:bg-white/10 flex items-center gap-3"
        >
          <Radio size={16} className="text-white/60" />
          Create Station
        </button>

        <div className="my-1 border-t border-white/10" />

        {hasAlbum && (
          <button
            onClick={() => handleAction(() => router.push(`/album/${track.album.id}`))}
            className="w-full text-left px-4 py-3 text-[14px] font-medium text-white transition-colors hover:bg-white/10 flex items-center gap-3"
          >
            <Disc3 size={16} className="text-white/60" />
            Go to Album
          </button>
        )}
        {hasArtist && (
          <button
            onClick={() => handleAction(() => router.push(`/artist/${track.artists.primary[0].id}`))}
            className="w-full text-left px-4 py-3 text-[14px] font-medium text-white transition-colors hover:bg-white/10 flex items-center gap-3"
          >
            <Mic2 size={16} className="text-white/60" />
            Go to Artist
          </button>
        )}

        <div className="my-1 border-t border-white/10" />

        <button
          onClick={() => handleAction(handleShare)}
          className="w-full text-left px-4 py-3 text-[14px] font-medium text-white transition-colors hover:bg-white/10 flex items-center gap-3"
        >
          <Share size={16} className="text-white/60" />
          Share
        </button>
      </div>
    );
  };

  // --- Mobile Bottom Sheet ---
  if (isMobile) {
    return (
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-[100]"
              onClick={onClose}
            />
            <motion.div
              ref={menuRef}
              initial={{ y: "100%", opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: "100%", opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed inset-x-0 bottom-0 z-[101] bg-[#1c1c1e] rounded-t-3xl pt-2 pb-safe shadow-2xl flex flex-col"
            >
              <div className="w-12 h-1.5 bg-white/20 rounded-full mx-auto my-3" />

              <div className="px-5 pb-4 pt-2 flex items-center gap-4 border-b border-white/10">
                <div className="relative w-14 h-14 rounded-md overflow-hidden flex-shrink-0 bg-white/10">
                  {getBestImageUrl(track.image) && (
                    <Image src={getBestImageUrl(track.image)!} alt={track.name} fill sizes="56px" className="object-cover" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-lg font-bold text-white truncate">{track.name}</h3>
                  <p className="text-sm text-white/50 truncate">{track.artists.primary.map(a => a.name).join(', ')}</p>
                </div>
              </div>

              <div className="overflow-y-auto max-h-[60vh] pb-6">
                {renderMenuItems()}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    );
  }

  // --- Desktop Portal Menu ---
  if (!isOpen || !position) return null;
  return createPortal(
    <AnimatePresence>
      {isOpen && (
        <motion.div
          ref={menuRef}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.15, ease: "easeOut" }}
          className="fixed z-[100] w-60 bg-[#1a1a1c] border border-white/10 rounded-xl shadow-2xl overflow-hidden backdrop-blur-xl"
          style={{
            // Initial position before useLayoutEffect kicks in
            left: position.x,
            top: position.y,
          }}
        >
          {renderMenuItems()}
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
}
