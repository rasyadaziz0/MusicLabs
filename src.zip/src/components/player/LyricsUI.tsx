'use client';

import { LrcLine } from '@/lib/utils/lrcParser';
import { Song } from '@/types/music';
import { motion } from 'framer-motion';
import { useState, useEffect } from 'react';
import { LyricsHeader } from './lyrics/LyricsHeader';
import { LyricLine } from './lyrics/LyricLine';
import { LyricsSkeleton } from './lyrics/LyricsSkeleton';
import './LyricsUI.css';

interface LyricsUIProps {
  currentTrack: Song;
  lines: LrcLine[];
  activeIndex: number;
  isSynced: boolean;
  isLoading: boolean;
  scrollRef: React.RefObject<HTMLDivElement | null>;
  onLineClick: (time: number, isPlaceholder?: boolean) => void;
  hideHeader?: boolean;
  currentTime?: number;
  romanizations?: Map<number, string>;
}

export default function LyricsUI({
  currentTrack,
  lines,
  activeIndex,
  isSynced,
  isLoading,
  scrollRef,
  onLineClick,
  hideHeader,
  currentTime = 0,
  romanizations,
}: LyricsUIProps) {
  const [showRomanization, setShowRomanization] = useState(true);
  const [isUserScrolling, setIsUserScrolling] = useState(false);
  const hasRomanizations = romanizations && romanizations.size > 0;

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;

    let scrollTimeout: NodeJS.Timeout;

    const handleScroll = () => {
      setIsUserScrolling(true);
      clearTimeout(scrollTimeout);
      scrollTimeout = setTimeout(() => {
        setIsUserScrolling(false);
      }, 3000);
    };

    el.addEventListener('wheel', handleScroll, { passive: true });
    el.addEventListener('touchmove', handleScroll, { passive: true });

    return () => {
      el.removeEventListener('wheel', handleScroll);
      el.removeEventListener('touchmove', handleScroll);
      clearTimeout(scrollTimeout);
    };
  }, [scrollRef]);

  // Auto-scroll logic (moved from useNowPlaying to respect isUserScrolling)
  useEffect(() => {
    if (activeIndex < 0 || !scrollRef.current || isUserScrolling) return;
    const el = scrollRef.current.querySelector(
      `[data-lyric-index="${activeIndex}"]`
    ) as HTMLElement | null;
    if (el && scrollRef.current) {
      const container = scrollRef.current;

      // On mobile, position active lyric slightly higher (at 20%). On desktop, we also move it higher (at 25% instead of 50%).
      const isMobile = window.innerWidth < 768;
      const offsetRatio = isMobile ? 0.20 : 0.20;

      const offset = el.offsetTop - (container.clientHeight * offsetRatio) + (el.clientHeight / 2);
      container.scrollTo({ top: offset, behavior: 'smooth' });
    }
  }, [activeIndex, lines, scrollRef, isUserScrolling]);

  return (
    <>
      <div
        style={{
          display: 'flex',
          height: '100%',
          width: '100%',
          padding: hideHeader ? '0' : '28px 32px',
          flexDirection: 'column',
          position: 'relative',
        }}
      >
        <LyricsHeader
          currentTrack={currentTrack}
          hasRomanizations={hasRomanizations || false}
          showRomanization={showRomanization}
          onToggleRomanization={() => setShowRomanization(!showRomanization)}
          hideHeader={hideHeader}
        />

        {/* Lyrics scroll */}
        <div
          ref={scrollRef}
          className="lyrics-scroll-area"
          style={{
            position: 'relative',
            flex: 1,
            overflowY: 'auto',
            scrollbarWidth: 'none',
            paddingRight: 8,
            paddingTop: '20vh',
            paddingBottom: '60vh',
            maskImage:
              'linear-gradient(to bottom, transparent 0%, black 12%, black 80%, transparent 100%)',
            WebkitMaskImage:
              'linear-gradient(to bottom, transparent 0%, black 12%, black 80%, transparent 100%)',
          }}
        >
          {isLoading ? (
            <LyricsSkeleton />
          ) : lines.length > 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, ease: 'easeOut' }}
            >
              {lines.map((line, index) => (
                <LyricLine
                  key={`${index}-${line.time}`}
                  line={line}
                  index={index}
                  activeIndex={activeIndex}
                  isSynced={isSynced}
                  currentTime={currentTime}
                  isUserScrolling={isUserScrolling}
                  romanText={showRomanization ? romanizations?.get(index) : undefined}
                  onLineClick={onLineClick}
                />
              ))}
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
              style={{
                display: 'flex',
                height: '100%',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 20,
                fontWeight: 500,
                color: 'rgba(255,255,255,0.3)',
              }}
            >
              Lirik tidak tersedia.
            </motion.div>
          )}
        </div>
      </div>
    </>
  );
}